import Agenda.Agenda;
import Citas.Cita;
import Citas.CitaTrabajo;
import Contactos.Contacto;
import Contactos.ContactoProfesional;
import Tareas.Tarea;
import Tareas.TareaSeguimiento;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class AgendaTest {
    Agenda agenda = new Agenda();
    Contacto roberto;
    ContactoProfesional cristina;
    Cita cita;
    CitaTrabajo citaTrabajo;
    Tarea tarea;
    TareaSeguimiento tareaSeguimiento;
    ArrayList<Contacto> asistentes = new ArrayList<>();
    ArrayList<String> temas = new ArrayList<>();
    LocalDate fecha = LocalDate.of(2025, 4, 21);
    LocalTime hora = LocalTime.of(15, 00);


    public AgendaTest() {

        roberto = new Contacto("Roberto", 600000000, "roberto@correo.com", "C/Calle, 1");
        cristina = new ContactoProfesional("Cristina", 600000001, "cristina@corre.com", "C/Calle, 2", "UAH", "Estudiante");

        agenda.addContacto(roberto);
        agenda.addContacto(cristina);

        asistentes.add(roberto);
        temas.add("Defensa PL2");
        temas.add("Evaluación PL2");

        cita = new Cita(fecha, hora, "NA7", asistentes);


        citaTrabajo = new CitaTrabajo(fecha, hora.plusHours(1), "NL8", asistentes, temas, 120);


        tarea = new Tarea("Defender la PL2", 5);


        tareaSeguimiento = new TareaSeguimiento("Evaluar la PL2", 10, LocalDate.now().plusDays(10), asistentes);


        agenda.addCita(cita);
        agenda.addCita(citaTrabajo);
        agenda.addTarea(tarea);
        agenda.addTarea(tareaSeguimiento);
    }

    @Test
    void addContacto() {
        assertThrows(IllegalArgumentException.class, () -> agenda.addContacto(roberto));
    }

    @Test
    void addCita() {
        assertThrows(IllegalArgumentException.class, () -> agenda.addCita(cita));
    }

    @Test
    void addTarea() {
        assertThrows(IllegalArgumentException.class, () -> agenda.addTarea(tarea));
    }

    @Test
    void removeContacto() {
        assertThrows(IllegalArgumentException.class, () -> agenda.removeContacto(555555555));
    }

}
