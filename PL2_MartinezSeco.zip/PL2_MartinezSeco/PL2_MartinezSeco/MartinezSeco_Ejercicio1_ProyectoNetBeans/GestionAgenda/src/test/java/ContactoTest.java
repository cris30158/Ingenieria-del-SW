import Contactos.Contacto;
import Contactos.ContactoProfesional;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactoTest {
    private ContactoProfesional contacto = new ContactoProfesional("Roberto", 600000000, "roberto@gmail.com", "C/Calle", "UAH", "Estudiante");

    @Test
    void crearContacto() {
        assertEquals("Roberto", contacto.getNombre());
        assertEquals(600000000, contacto.getTelefono());
        assertEquals("roberto@gmail.com", contacto.getEmail());
        assertEquals("C/Calle", contacto.getDireccion());
    }

    @Test
    void emailCorrecto() {
        Contacto contacto = new Contacto("Roberto", 600000000, "roberto@gmail.com", "C/Calle");
        assertTrue(Contacto.validarEmail(contacto.getEmail()));
    }

    @Test
    void emailIncorrecto() {

        assertFalse(Contacto.validarEmail("roberto.com"));
    }

    @Test
    void telefono() {
        int tfn1 = 600000000;
        int tfn2 = 33;

        assertTrue(Contacto.validarTelefono(tfn1));
        assertFalse(Contacto.validarTelefono(tfn2));
    }

    @Test
    void setEmpresa() {
        assertThrows(IllegalArgumentException.class, () -> this.contacto.setEmpresa(""));
    }

    @Test
    void setCargo() {
        assertThrows(IllegalArgumentException.class, () -> this.contacto.setCargo(""));
    }

    @Test
    void setNombre() {
        assertThrows(IllegalArgumentException.class, () -> this.contacto.setNombre(""));
    }

    @Test
    void setDireccion() {
        assertThrows(IllegalArgumentException.class, () -> this.contacto.setDireccion(""));
    }

    @Test
    void setEmail() {
        assertThrows(IllegalArgumentException.class, () -> this.contacto.setEmail("roberto.com"));
    }

    @Test
    void setTelefono() {
        assertThrows(IllegalArgumentException.class, () -> this.contacto.setTelefono(33));
    }
}
