import Citas.Cita;
import Citas.CitaTrabajo;
import Contactos.Contacto;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class CitaTest {
    private ArrayList<Contacto> contactos = new ArrayList<>();
    private Contacto contacto = new Contacto("Roberto", 600000000, "roberto@correo.com", "Calle");
    private Contacto contacto1 = new Contacto("Roto", 600001000, "rto@correo.com", "Calle1");

    public CitaTest() {
        this.contactos.add(contacto);
    }

    @Test
    void fecha() {
        Cita c = new Cita(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos);
        assertDoesNotThrow(() -> c.setFecha(LocalDate.now().plusDays(2)));
        assertThrows(IllegalArgumentException.class, () -> c.setFecha(LocalDate.now().minusDays(5)));
    }

    @Test
    void hora() {
        Cita c = new Cita(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos);
        assertDoesNotThrow(() -> c.setHora(LocalTime.now().plusHours(5)));
        assertThrows(IllegalArgumentException.class, () -> c.setHora(LocalTime.now().minusHours(10)));
    }

    @Test
    void lugar() {
        Cita c = new Cita(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos);
        assertThrows(IllegalArgumentException.class, () -> c.setLugar(""));
        assertDoesNotThrow(() -> c.setLugar("NA9"));
    }

    @Test
    void addPersona() {
        Cita c = new Cita(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos);
        assertThrows(IllegalArgumentException.class, () -> c.addPersona(contacto));
        assertDoesNotThrow(() -> c.addPersona(contacto1));
    }

    @Test
    void removePersona() {
        Cita c = new Cita(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos);
        assertThrows(IllegalArgumentException.class, () -> c.removePersona(contacto));
    }

    @Test
    void setDuracion() {
        ArrayList<String> temas = new ArrayList<>();
        temas.add("HOLA");
        CitaTrabajo c = new CitaTrabajo(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos, temas, 120);
        assertThrows(IllegalArgumentException.class, () -> c.setDuracion(-10));
        assertDoesNotThrow(() -> c.setDuracion(20));
    }

    @Test
    void removeTemas() {
        ArrayList<String> temas = new ArrayList<>();
        temas.add("HOLA");
        CitaTrabajo c = new CitaTrabajo(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos, temas, 120);
        assertThrows(IllegalArgumentException.class, () -> c.removeTema("HOLA"));
    }

    @Test
    void addTemas() {
        ArrayList<String> temas = new ArrayList<>();
        temas.add("HOLA");
        CitaTrabajo c = new CitaTrabajo(LocalDate.now(), LocalTime.now().plusHours(1), "NA5", contactos, temas, 120);
        assertThrows(IllegalArgumentException.class, () -> c.addTema("HOLA"));
    }
}
