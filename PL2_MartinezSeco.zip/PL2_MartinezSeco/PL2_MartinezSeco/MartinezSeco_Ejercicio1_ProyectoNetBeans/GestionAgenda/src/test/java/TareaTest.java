import Contactos.Contacto;
import Estados.Estado;
import Tareas.TareaSeguimiento;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class TareaTest {
    private ArrayList list = new ArrayList();
    private Contacto contacto = new Contacto("Roberto", 600000000, "roberto@correo.com", "Calle");
    private Contacto contacto1 = new Contacto("Robertos", 600000001, "roberto@correo.com", "Calle");
    private TareaSeguimiento t;

    public TareaTest() {
        this.list.add(this.contacto);
        this.t = new TareaSeguimiento("Tarea", 4, LocalDate.now().plusDays(1), this.list);
    }

    @Test
    void fecha() {
        assertThrows(IllegalArgumentException.class, () -> this.t.setFechaLimite(LocalDate.now().minusDays(1)));
        assertDoesNotThrow(() -> this.t.setFechaLimite(LocalDate.now().plusMonths(1)));
    }

    @Test
    void addResponsable() {
        assertThrows(IllegalArgumentException.class, () -> this.t.removeResponsable(contacto));
        assertDoesNotThrow(() -> this.t.addResponsable(contacto1));
    }

    @Test
    void setDescripcion() {
        assertThrows(IllegalArgumentException.class, () -> this.t.setDescripcion(""));
        assertDoesNotThrow(() -> this.t.setDescripcion("HOLA"));
    }

    @Test
    void setPrioridad() {
        assertDoesNotThrow(() -> this.t.setPrioridad(5));
    }

    @Test
    void setEstado() {
        assertThrows(IllegalArgumentException.class, () -> this.t.setEstado(Estado.SIN_EMPEZAR));
        assertDoesNotThrow(() -> this.t.setEstado(Estado.FINALIZADO));
    }
}
