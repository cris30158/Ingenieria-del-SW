package Citas;

import Contactos.Contacto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Cita {
    // Atributos
    private LocalDate fecha;
    private LocalTime hora;
    private String lugar;
    private ArrayList<Contacto> personas;

    public Cita(LocalDate fecha, LocalTime hora, String lugar, ArrayList<Contacto> personas) {
        LocalDate hoy = LocalDate.now();
        if (fecha.isBefore(hoy)) {
            throw new IllegalArgumentException("No puedes crear una cita para una fecha que ya pasó");
        }

        if (fecha.equals(hoy) && hora.isBefore(LocalTime.now())) {
            throw new IllegalArgumentException("No puedes crear una cita para una fecha que ya pasó");
        }

        if (lugar.isEmpty()) throw new IllegalArgumentException("Debes indicar un lugar");

        if (personas.isEmpty()) throw new IllegalArgumentException("Debes poner al menos una persona");

        this.fecha = fecha;
        this.hora = hora;
        this.lugar = lugar;
        this.personas = personas;
    }

    // Métodos

    // Getters
    public LocalDate getFecha() {
        return this.fecha;
    }

    public LocalTime getHora() {
        return this.hora;
    }

    public String getLugar() {
        return this.lugar;
    }

    public ArrayList<Contacto> getPersonas() {
        return this.personas;
    }

    // Setters

    public void setFecha(LocalDate fecha) {
        if (!fecha.isBefore(LocalDate.now())) {
            this.fecha = fecha;
        } else {
            throw new IllegalArgumentException("No puedes poner esa fecha");
        }

    }

    public void setHora(LocalTime hora) {
        if (this.fecha.equals(LocalDate.now()) && hora.isBefore(LocalTime.now())) {
            throw new IllegalArgumentException("NO puedes poner esa hora");
        } else {
            this.hora = hora;
        }
    }

    public void setLugar(String lugar) {
        if (!lugar.isEmpty()) {
            this.lugar = lugar;
        } else {
            throw new IllegalArgumentException("Tienes que poner un lugar");
        }
    }

    public void addPersona(Contacto persona) {
        if (!this.personas.contains(persona)) this.personas.add(persona);
        else throw new IllegalArgumentException();
    }

    public void removePersona(Contacto persona) {
        if (this.personas.contains(persona) && this.personas.size() > 1) this.personas.remove(persona);
        else throw new IllegalArgumentException();
    }
}
