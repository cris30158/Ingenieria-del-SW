import Agenda.Agenda;
import Citas.Cita;
import Citas.CitaTrabajo;
import Contactos.Contacto;
import Contactos.ContactoProfesional;
import Tareas.Tarea;
import Tareas.TareaSeguimiento;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class GestionAgenda {

    public static void main(String[] args) {
        Agenda agenda = new Agenda();

        Contacto roberto = new Contacto("Roberto", 600000000, "roberto@correo.com", "C/Calle, 1");
        ContactoProfesional cristina = new ContactoProfesional("Cristina", 600000001, "cristina@corre.com", "C/Calle, 2", "UAH", "Estudiante");

        agenda.addContacto(roberto);
        agenda.addContacto(cristina);

        LocalDate fecha = LocalDate.of(2025, 6, 21);
        LocalTime hora = LocalTime.of(15, 00);
        ArrayList<Contacto> asistentes = new ArrayList<>();
        ArrayList<String> temas = new ArrayList<>();

        asistentes.add(roberto);
        temas.add("Defensa PL2");
        temas.add("Evaluación PL2");

        Cita cita = new Cita(fecha, hora, "NA7", asistentes);
        agenda.addCita(cita);

        CitaTrabajo citaTrabajo = new CitaTrabajo(fecha, hora.plusHours(1), "NL8", asistentes, temas, 120);
        agenda.addCita(citaTrabajo);

        Tarea tarea = new Tarea("Defender la PL2", 5);
        agenda.addTarea(tarea);

        TareaSeguimiento tareaSeguimiento = new TareaSeguimiento("Evaluar la PL2", 10, LocalDate.now().plusDays(10), asistentes);
        agenda.addTarea(tareaSeguimiento);

        agenda.print();

        agenda.removeCita(cita);
        agenda.removeCita(citaTrabajo);
        agenda.removeTarea(tarea);
        agenda.removeTarea(tareaSeguimiento);
        agenda.removeContacto(cristina);
        agenda.removeContacto(600000000);

        System.out.println();
        agenda.print();


    }
}
