package Contactos;

public class ContactoProfesional extends Contacto {
    //Atributos
    private String empresa, cargo;

    //Constructor
    public ContactoProfesional(String nombre, int telefono, String email, String direccion, String empresa, String cargo) {
        super(nombre, telefono, email, direccion);

        if (empresa.isEmpty() || cargo.isEmpty())
            throw new IllegalArgumentException("Debes completar los campos empresa y cargo");

        this.empresa = empresa;
        this.cargo = cargo;
    }

    //Métodos

    // Getters
    public String getEmpresa() {
        return this.empresa;
    }

    public String getCargo() {
        return this.cargo;
    }

    // Setters
    public void setEmpresa(String empresa) {
        if (!empresa.isEmpty()) this.empresa = empresa;
        else throw new IllegalArgumentException();
    }

    public void setCargo(String cargo) {
        if (!cargo.isEmpty()) this.cargo = cargo;
        else throw new IllegalArgumentException();
    }
}
