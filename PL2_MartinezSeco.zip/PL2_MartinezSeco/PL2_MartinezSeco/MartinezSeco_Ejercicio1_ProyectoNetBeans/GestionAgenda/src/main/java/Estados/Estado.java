package Estados;

public enum Estado {
    SIN_EMPEZAR,
    EMPEZADO,
    FINALIZADO
}
