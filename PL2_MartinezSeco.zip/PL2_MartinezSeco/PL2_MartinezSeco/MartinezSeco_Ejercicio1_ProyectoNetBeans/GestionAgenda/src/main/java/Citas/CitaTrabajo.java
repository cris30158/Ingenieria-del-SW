package Citas;

import Contactos.Contacto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class CitaTrabajo extends Cita {
    private ArrayList<String> temas;
    private int duracion;

    public CitaTrabajo(LocalDate fecha, LocalTime hora, String lugar, ArrayList<Contacto> personas, ArrayList<String> temas, int duracion) {
        super(fecha, hora, lugar, personas);

        if (temas.size() == 0) throw new IllegalArgumentException("Tienes que incluir al menos un tema");
        if (duracion <= 0) throw new IllegalArgumentException("La reunión tiene que tener una duración válida");

        this.temas = temas;
        this.duracion = duracion;
    }

    public ArrayList<String> getTemas() {
        return this.temas;
    }

    public int getDuracion() {
        return this.duracion;
    }

    public void addTema(String tema) {
        if (!this.temas.contains(tema)) this.temas.add(tema);
        else throw new IllegalArgumentException();
    }

    public void removeTema(String tema) {
        if (this.temas.contains(tema) && this.temas.size() > 1) this.temas.remove(tema);
        else throw new IllegalArgumentException();
    }

    public void setDuracion(int duracion) {
        if (duracion > 0) this.duracion = duracion;
        else throw new IllegalArgumentException();
    }
}
