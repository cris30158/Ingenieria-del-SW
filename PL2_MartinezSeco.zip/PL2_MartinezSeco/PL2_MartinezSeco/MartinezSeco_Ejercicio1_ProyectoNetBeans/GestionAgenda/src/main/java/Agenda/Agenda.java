package Agenda;

import Citas.Cita;
import Contactos.Contacto;
import Estados.Estado;
import Tareas.Tarea;

import java.util.ArrayList;
import java.util.Comparator;

public class Agenda {
    private ArrayList<Contacto> contactos = new ArrayList<>();
    private ArrayList<Cita> citas = new ArrayList<>();
    private ArrayList<Tarea> tareas = new ArrayList<>();

    public Agenda() {

    }

    public void addContacto(Contacto contacto) {
        boolean sePuede = !this.contactos.contains(contacto);

        for (Contacto c : contactos) {
            if (c.getTelefono() == contacto.getTelefono() || c.getEmail().equals(contacto.getEmail())) {
                sePuede = false;
                break;
            }
        }

        if (sePuede) this.contactos.add(contacto);
        else throw new IllegalArgumentException();
    }

    public void addCita(Cita cita) {
        boolean sePuede = true;

        for (Cita c : this.citas) {
            if (c.getFecha().equals(cita.getFecha()) && c.getHora().equals(cita.getHora())) {
                sePuede = false;
                break;
            }
        }

        if (sePuede) this.citas.add(cita);
        else throw new IllegalArgumentException();
    }

    public void addTarea(Tarea tarea) {
        if (!this.tareas.contains(tarea)) {
            this.tareas.add(tarea);
            this.ordenarTareasPrioridad();
        } else throw new IllegalArgumentException();
    }

    public void removeContacto(Contacto contacto) {
        this.contactos.remove(contacto);
    }

    public void removeContacto(int telefono) {
        int i = 0;
        boolean encontrado = false;

        while (!encontrado && i < this.contactos.size()) {
            if (this.contactos.get(i).getTelefono() == telefono) {
                encontrado = true;
            }
            i++;
        }

        if (encontrado) {
            this.contactos.remove(i - 1);
        } else {
            throw new IllegalArgumentException();
        }
    }

    public void removeCita(Cita cita) {
        this.citas.remove(cita);
    }

    public void removeTarea(Tarea tarea) {
        this.tareas.remove(tarea);
    }

    private void ordenarTareasPrioridad() {
        this.tareas.sort(Comparator.comparing(Tarea::getPrioridad, Comparator.reverseOrder()));
    }

    public void print() {
        System.out.println("--- AGENDA ---");
        System.out.println("--- CONTACTOS ---");
        for (Contacto c : this.contactos) {
            System.out.println("Nombre: " + c.getNombre() + " | Email: " + c.getEmail());
        }

        System.out.println("--- CITAS ---");
        System.out.println(this.citas.size());
        for (Cita c : this.citas) {

            System.out.println(c.getFecha() + " " + c.getHora() + " " + c.getLugar());
        }

        System.out.println("--- TAREAS ---");
        for (Tarea t : this.tareas) {
            if (t.getEstado() != Estado.FINALIZADO) {
                System.out.println(t.getDescripcion() + " Prioridad: " + t.getPrioridad());
            }
        }

    }
}
