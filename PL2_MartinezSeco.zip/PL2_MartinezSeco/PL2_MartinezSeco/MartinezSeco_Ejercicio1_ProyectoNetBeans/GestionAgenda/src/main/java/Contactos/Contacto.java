package Contactos;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Contacto {
    // Atributos
    private String nombre, email, direccion;
    private int telefono;

    // Constructor
    public Contacto(String nombre, int telefono, String email, String direccion) {

        if (nombre.isEmpty()) throw new IllegalArgumentException("Tienes que poner un nombre");
        if (!this.validarTelefono(telefono)) throw new IllegalArgumentException("El teléfono debe ser válido");
        if (!this.validarEmail(email)) throw new IllegalArgumentException("El email debe ser válido");
        if (direccion.isEmpty()) throw new IllegalArgumentException("La dirección no puede estar vacía");

        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
        this.direccion = direccion;
    }

    // Métodos

    // Getters
    public String getNombre() {
        return this.nombre;
    }

    public String getEmail() {
        return this.email;
    }

    public String getDireccion() {
        return this.direccion;
    }

    public int getTelefono() {
        return this.telefono;
    }

    // Setters
    public void setNombre(String nombre) {
        // El nombre no puede ser nulo
        if (!nombre.isEmpty()) this.nombre = nombre;
        else throw new IllegalArgumentException();
    }

    public void setEmail(String email) {
        if (validarEmail(email)) this.email = email;
        else throw new IllegalArgumentException();
    }

    public void setDireccion(String direccion) {
        if (!direccion.isEmpty()) this.direccion = direccion;
        else throw new IllegalArgumentException();
    }

    public void setTelefono(int telefono) {
        if (validarTelefono(telefono)) this.telefono = telefono;
        else throw new IllegalArgumentException();
    }

    public static boolean validarTelefono(int telefono) {
        boolean resultado = false;
        String tfn = "" + telefono;
        if (tfn.length() == 9) resultado = true;

        return resultado;
    }

    public static boolean validarEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }

        String patronEmail = "^[A-Za-z0-9+_.-]+@(.+)$";

        Pattern pattern = Pattern.compile(patronEmail);
        Matcher matcher = pattern.matcher(email);

        return matcher.matches();
    }

}
