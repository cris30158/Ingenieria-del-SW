package Tareas;

import Estados.Estado;

public class Tarea {
    private String descripcion;
    private int prioridad;
    private Estado estado;

    public Tarea(String descripcion, int prioridad) {
        if (descripcion.isEmpty()) throw new IllegalArgumentException("Tienes que incluir una excepción");
        if (prioridad < 0) throw new IllegalArgumentException("Tienes que incluir una prioridad no negativa");

        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.estado = Estado.SIN_EMPEZAR;
    }

    public String getDescripcion() {
        return this.descripcion;
    }

    public int getPrioridad() {
        return this.prioridad;
    }

    public Estado getEstado() {
        return this.estado;
    }

    public void setDescripcion(String descripcion) {
        if (!descripcion.isEmpty()) {
            this.descripcion = descripcion;
        } else throw new IllegalArgumentException();
    }

    public void setPrioridad(int prioridad) {
        if (this.prioridad >= 0) this.prioridad = prioridad;
        else throw new IllegalArgumentException();
    }

    public void setEstado(Estado estado) {
        if (!estado.equals(Estado.SIN_EMPEZAR)) this.estado = estado;
        else throw new IllegalArgumentException();
    }
}
