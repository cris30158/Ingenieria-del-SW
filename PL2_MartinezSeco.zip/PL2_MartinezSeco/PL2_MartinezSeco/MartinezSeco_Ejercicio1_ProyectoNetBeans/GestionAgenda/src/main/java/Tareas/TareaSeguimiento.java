package Tareas;

import Contactos.Contacto;

import java.time.LocalDate;
import java.util.ArrayList;

public class TareaSeguimiento extends Tarea {
    private LocalDate fechaLimite;
    private ArrayList<Contacto> responsables;

    public TareaSeguimiento(String descripcion, int prioridad, LocalDate fechaLimite, ArrayList<Contacto> responsables) {
        super(descripcion, prioridad);

        if (fechaLimite.isBefore(LocalDate.now()))
            throw new IllegalArgumentException("Debes introducir una fecha válida");
        if (responsables.isEmpty()) throw new IllegalArgumentException("Tienes que poner al menos un responsable");

        this.responsables = responsables;
        this.fechaLimite = fechaLimite;
    }

    public LocalDate getFechaLimite() {
        return this.fechaLimite;
    }

    public ArrayList<Contacto> getResponsables() {
        return this.responsables;
    }

    public void setFechaLimite(LocalDate fechaLimite) {
        if (fechaLimite.isAfter(LocalDate.now())) {
            this.fechaLimite = fechaLimite;
        } else {
            throw new IllegalArgumentException();
        }
    }

    public void addResponsable(Contacto responsable) {
        if (!this.responsables.contains(responsable)) {
            this.responsables.add(responsable);
        } else {
            throw new IllegalArgumentException();
        }
    }

    public void removeResponsable(Contacto responsable) {
        if (this.responsables.contains(responsable) && this.responsables.size() > 1) {
            this.responsables.remove(responsable);
        } else throw new IllegalArgumentException();
    }
}
